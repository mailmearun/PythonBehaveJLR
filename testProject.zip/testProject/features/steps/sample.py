import time

# from selenium import webdriver
# from selenium.webdriver.common.by import By
#
# driver = webdriver.Chrome()
# driver.get("https://www.saucedemo.com/")
# time.sleep(15)
# html = driver.title  # Getting Source of Current URL / Web-Page Loaded
# print(html)
# driver.find_element(By.XPATH, "//input[@id='user-name']").send_keys('standard_user')
# driver.find_element(By.XPATH, "//input[@id='password']").send_keys('secret_sauce')
# driver.find_element(By.XPATH, "//input[@id='login-button']").click()
# # for name in list_name:
# #     print(name.text)
# time.sleep(15)
